declare module "*.png" {
    const value: string;
}
declare module "*.jpg" {
    const value: string;
}
declare module "*.jpeg" {
    const value: string;
}
declare module "*.svg" {
    const value: string;
}
